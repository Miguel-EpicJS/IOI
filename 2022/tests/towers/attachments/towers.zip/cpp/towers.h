#include <vector>

void init(int N, std::vector<int> H);
int max_towers(int L, int R, int D);
